<?php

public function userLogin($service_data)
		{
			// 1 => manually  AND 2 => social
			
			$username       = $service_data['username']; 
			$password       = $service_data['password']; 
		    $device_token   = $service_data['device_token']; 
		    $device_type    = $service_data['device_type']; 
		    $login_type     = $service_data['login_type']; 
		    $fb_id          = $service_data['fb_id']; 
		    $google_id      = $service_data['google_id']; 
		    

		    if(!empty($login_type)){
		      
		    if($login_type=='1'){
                
                $password1  = md5($password);
			if (!empty($username) and !empty($password1)){

				$sql = "SELECT * From `app_user` WHERE full_name = '$username' AND password = '$password1' AND device_token ='$device_token'";  
				$result = mysql_query($sql);
				if(mysql_num_rows($result)>0){
                    $row = mysql_fetch_array($result)  
                    
                    $data[] = array('userId'=>$row['id'],'name'=>$row['name'],'image'=>$image_path.$row['image'],'contact'=>$row['phone'],'email'=>$row['email'],'creat_date'=>$row['creat_date'],'edit_date'=>$row['update_date']); 
                
					$response['message']="Login successfully done";
					$response['msg_code']=102;
					$response['data'] = $data;
				}else{

					$response['message']="Username Or password Incorrect .";
					$response['msg_code']=103; 
				}
												
							

			}else{ 
					$response['message']="Please Enter Email And Password.";
					$response['msg_code']=103;
			}
                 
		    }elseif($login_type=='2'){

                $sql_1    = "SELECT * From `app_user` WHERE fb_id ='$fb_id'";  
				$result_1 = mysql_query($sql_1);
				if(mysql_num_rows($result_1)>0){
                   $row_1 = mysql_fetch_array($result_1)  
                    
                    $data[] = array('userId'=>$row_1['id'],'name'=>$row_1['name'],'image'=>$image_path.$row_1['image'],'contact'=>$row_1['phone'],'email'=>$row_1['email'],'creat_date'=>$row_1['creat_date'],'edit_date'=>$row_1['update_date']); 
                
					$response['message']="Login successfully done";
					$response['msg_code']=102;
					$response['data'] = $data;
				}else{

					$response['message']="Invailid Facebook ID.";
					$response['msg_code']=101; 
				}    

	                

		    }elseif($login_type=='3'){


                $sql_2    = "SELECT * From `app_user` WHERE google_id ='$google_id'";  
				$result_2 = mysql_query($sql_2);
				if(mysql_num_rows($result_2)>0){
                   $row_2 = mysql_fetch_array($result_2)  
                    
                    $data[] = array('userId'=>$row_2['id'],'name'=>$row_2['name'],'image'=>$image_path.$row_2['image'],'contact'=>$row_2['phone'],'email'=>$row_2['email'],'creat_date'=>$row_2['creat_date'],'edit_date'=>$row_2['update_date']); 
                
					$response['message']="Login successfully done";
					$response['msg_code']=102;
					$response['data'] = $data;
				}else{

					$response['message']="Invailid Google ID.";
					$response['msg_code']=101; 
				}
		    }	


		      }else{
                 
                $response['message']  = "There is Some Problem.";
				$response['msg_code'] = 103; 

		      }
            
            return json_encode($response);
		}