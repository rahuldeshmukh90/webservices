<?php

	
	//please check line number 66 if (mysql_affected_rows($result) == 0)
	include 'config.php';
	mysql_query('SET names=utf8');
	mysql_query('SET character_set_client=utf8');
	mysql_query('SET character_set_connection=utf8');
	mysql_query('SET character_set_results=utf8');
	mysql_query('SET collation_connection=utf8_general_ci');
    mysql_query('SET character_set_connection=utf8mb4');

	
	$response =array();
	$data     =array();
	$productData=array();

	//require_once __DIR__ . '/firebase.php';
    //require_once __DIR__ . '/push.php'; 
         
	class api
	{
	    
	   
		public function __construct() { 
		 	$this->upload_image_path = $_SERVER['DOCUMENT_ROOT']. '/software/uploads/';
			
			//show image path
			$this->image_path = 'http://'.$_SERVER['HTTP_HOST']. '/software/uploads/';
			$this->product_image_path = 'http://'.$_SERVER['HTTP_HOST']. '/software/wp_admin/assets/uploads/';
			$this->slider_image_path  = 'http://'.$_SERVER['HTTP_HOST']. '/software/wp_admin/upload/';
			
			header( 'Content-Type: application/json; charset=utf-8');
		 	mysql_query("SET character_set_results=utf8");

	    } 

	    /*-----------for current time----------------*/

	    public function default_datetime_zone($date=null)
        {
			date_default_timezone_set("Asia/Kolkata");
			return $today_date=date("Y-m-d h:i:s");
		}
             
		/*----------SERVICE NO.1-user registration-------------*/

        public function SingUpUser($service_data)
		{
			
            $addedDate    = $this->default_datetime_zone();
			$documentpath = $this->upload_image_path; 
		    $name         = $service_data['name']; 
            $email        = $service_data['email'];
			$contact      = $service_data['contact'];
			$pass         = $service_data['password'];
			$image        = $service_data['image'];
			$password     = md5($pass);
			$randomString = rand(10000, 99999);
             
			if(!empty($image)){ 
				   
							$filename1 = md5(time()).'.jpg';
							$base1=$image;
							$binary1 = base64_decode($base1);         
							//header('Content-Type: bitmap; charset=utf-8');
							$file1 = fopen($documentpath.$filename1,  'wb');
							$addImages1=$filename1;
							fwrite($file1, $binary1);
							fclose($file1);
				  
			}
			$image = (!empty($addImages1))?$addImages1:('default.jpg'); 
            $sql = "SELECT * From `customers` WHERE email = '$email'";
			$result = mysql_query($sql);
            if (mysql_num_rows($result)>0){

					$response['message']  ="Email is already exists please try New email.";
                    $response['msg_code'] =0;

				} else{	

					$int_sql = "INSERT INTO `customers`(`name`, `email`, `phone`, `password`, `image` ,`creat_date`, `update_date`,`randomString`) VALUES ('$name', '$email','$contact','$password', '$image' ,'$addedDate','$addedDate','$randomString')";

					$query=mysql_query($int_sql) or die(mysql_error());
					if(mysql_affected_rows()>0)
					{
						$response['message']="User is successfully Register";
					    $response['msg_code']=1;
					}else{
                        $response['message']="User is not added please try again.";
                    	$response['msg_code']=0;
                    }
               
                } 
           

			return json_encode($response);
		}

/*------------------------------SERVICE NO.2-for user login---------------------------------------------------*/

		public function userLogin($service_data)
		{
			// 1 => manually  AND 2 => social
			$image_path = $this->image_path; 
		    $login_type       = $service_data['type']; // User login type if user login with facebook , type is social otherw	ise manual  

		    if(!empty($login_type)){
		      
		    if($login_type=='1'){
                
                $email      = $service_data['email'];
			    $pass       = $service_data['password']; 
			    $password1  = md5($pass);
			  
	        if (!empty($email) and !empty($password1)){

				$sql = "SELECT * From customers WHERE email = '$email' and password = '$password1' ";  
				$result = mysql_query($sql);
				if(mysql_num_rows($result)>0){
                $row1=mysql_fetch_array($result);
                $id = $row1['id'];
                $curre_update = "update `customers` SET `active_status`='1' WHERE `id`='$id'";
                $result1       = mysql_query($curre_update);
                if(mysql_num_rows($result)>0){

                    $sql1 = "SELECT * From customers WHERE id = '$id' and `active_status`='1'";
                    $result2 = mysql_query($sql1);
				    if(mysql_num_rows($result2)>0){
                    $row=mysql_fetch_array($result2);

                    $data[] = array('userId'=>$row['id'],'name'=>$row['name'],'image'=>$image_path.$row['image'],'contact'=>$row['phone'],'email'=>$row['email'],'creat_date'=>$row['creat_date'],'edit_date'=>$row['update_date']);   
                    } 
                }
					$response['message']="Login successfully done";
					$response['msg_code']=1;
					$response['data'] = $data;
				}else{

					$response['message']="Username Or password Incorrect .";
					$response['msg_code']=0; 
				}
												
							

			}else{ 
					$response['message']="Please Enter Email And Password.";
					$response['msg_code']=0;
			}
                 
		    }elseif($login_type=='2'){

                    $addedDate    = $this->default_datetime_zone();
					$documentpath = $this->upload_image_path;
				    $name         = $service_data['name']; 
		            $email        = $service_data['email'];
					$contact      = $service_data['contact'];
					$image        = $service_data['image'];
					$password     = md5($password1);
					$randomString = rand(10000, 99999);

	                if ((!empty($email)) || (!empty($contact))){
	                   
	                $sql1 = "SELECT * From customers WHERE `email` = '$email'"; 
					$result1 = mysql_query($sql1);
					if(mysql_num_rows($result1)>0){

	                $row2=mysql_fetch_array($result1);
	                $id = $row2['id'];

	                /***********************************/
                    $curre_update1 = "UPDATE `customers` SET `active_status`='1' WHERE `id`='$id'";
	                $result_rw       = mysql_query($curre_update1);

	                $sql_2 = "SELECT * From customers WHERE id = '$id' AND `active_status` = '1'";
	                $result_2 = mysql_query($sql_2);
					if(mysql_num_rows($result_2)>0){
                    
                    $row_d =mysql_fetch_array($result_2);

	                $data[] = array('userId'=>$row_d['id'],'name'=>$row_d['name'],'contact'=>$row_d['phone'],'email'=>$row_d['email'],'image'=>$row_d['image'],'creat_date'=>$row_d['creat_date'],'edit_date'=>$row_d['update_date']);   


	                
	                }else{

                    $curre_update1 = "UPDATE `customers` SET `active_status`='1' WHERE `id`='$id'";
	                $result_rw       = mysql_query($curre_update1);                     
                    
                    $row_d =mysql_fetch_array($result_2);

	                $data[] = array('userId'=>$row_d['id'],'name'=>$row_d['name'],'contact'=>$row_d['phone'],'email'=>$row_d['email'],'image'=>$row_d['image'],'creat_date'=>$row_d['creat_date'],'edit_date'=>$row_d['update_date']);   

                    } 

	                    $response['message']="Login successfully done";
						$response['msg_code']=1;
						$response['data'] = $data;

					

					/******************************/
					}else{

                        if(filter_var($image, FILTER_VALIDATE_URL))
						{
						    
						    $image_url = $service_data['image'];
						}
						elseif( base64_encode(base64_decode($image, true)) === $image){
						 
						    if(!empty($image)){ 
							   
										$filename1 = md5(time()).'.jpg';
										$base1=$image;
										$binary1 = base64_decode($base1);         
										//header('Content-Type: bitmap; charset=utf-8');
										$file1 = fopen($documentpath.$filename1,  'wb');
										$addImages1=$filename1;
										fwrite($file1, $binary1);
										fclose($file1);
							  
						}
						
						$image_url = (!empty($addImages1))?$addImages1:('default.jpg'); 

						}

			            $int_sql = "INSERT INTO `customers`(`name`, `email`, `phone`, `password`, `image` ,`creat_date`, `update_date`,`randomString`,`active_status`) VALUES ('$name', '$email','$contact','$password', '$image_url' ,'$addedDate','$addedDate','$randomString','1')"; 

						$query    = mysql_query($int_sql) or die(mysql_error());
						$insertId = mysql_insert_id(); 
                        if(mysql_affected_rows()>0)
						{

							if($insertId){
						
							$social_q   = "SELECT * From customers WHERE id = '$insertId' and `active_status`='1'";
			                $social_run = mysql_query($social_q);
							if(mysql_num_rows($social_run)>0){
			                $social_row =mysql_fetch_array($social_run);

			                $data[] = array('userId'=>$social_row['id'],'name'=>$social_row['name'],'contact'=>$social_row['phone'],'email'=>$social_row['email'],'creat_date'=>$social_row['creat_date'],'edit_date'=>$social_row['update_date']);   
			                }

			                $response['message']  = "Login successfully done";
						    $response['msg_code'] = 1;
						    $response['data']     = $data;

						}else{
                            
                            $response['message']  = "There is Some Problem , Plaese Try After Some Time";
						    $response['msg_code'] = 0;

						}

						}else{
	                        $response['message']="User is not added please try again.";
	                    	$response['msg_code']=0;
	                    }
			               
			          
                //END 
					}    
                 }else{
                    
                    $response['message']  = "1 OR More Field is Missing.";
				    $response['msg_code'] = 0; 

                 } 

		    }	


		      }else{
                 
                $response['message']  = "Type field is empty.";
				$response['msg_code'] = 0; 

		      }
            
            return json_encode($response);
		}
/*******************************SERVICE NO.3-FOR LOGOUT*********************************************/

	public function logout($service_data)
		{
            
            $userId = $service_data['userId']; 
            
            if (!empty($userId)){
                
                $sql_query = "SELECT * From customers WHERE id = '$userId' and `active_status`='1'";
	            $run  = mysql_query($sql_query);
				
				if(mysql_num_rows($run)>0){
                  
                $sql = "update `customers` SET `active_status`='0' WHERE `id`='$userId'";
                $result = mysql_query($sql);
                if($result){

                    $response['message']="Logout successfully done";
		            $response['msg_code']=1;
				
                }else{
                    
                    $response['message']  ="Logout Failled.";
		            $response['msg_code'] =0; 
                }

				}else{
 
                    $response['message']  = "Error.";
		            $response['msg_code'] = 0; 
				}

			     
            
                }else{
			        
			        $response['message']="error";
			        $response['msg_code']=0;
		}

			return json_encode($response);
    }

/*********************************************************************/
/*================SERVICE NO.4 -FOR EDIT USER=======================*/

    function editUserInfo($service_data)
		{
			
            $addedDate    = $this->default_datetime_zone();
			$documentpath = $this->upload_image_path;
			$id           = $service_data['userId'];
			$image        = $service_data['image'];
			
			if(!empty($service_data['name'])){ $name = $service_data['name']; }else{ $name = ''; }
		    if(!empty($service_data['email'])){ $email = $service_data['email']; }else{ $email = ''; }
		    if(!empty($service_data['contact'])){ $contact = $service_data['contact']; }else{ $contact = '';}
			if(!empty($id)){

			$randomString = rand(10000, 99999);

			if(!empty($image)){ 
				   
							$filename1 = md5(time()).'.jpg';
							$base1=$image;
							$binary1 = base64_decode($base1);         
							//header('Content-Type: bitmap; charset=utf-8');
							$file1 = fopen($documentpath.$filename1,  'wb');
							$addImages1=$filename1;
							fwrite($file1, $binary1);
							fclose($file1);
				  
			}
			$image = (!empty($addImages1))?$addImages1:('default.jpg'); 
            	
                    $updt_user = "UPDATE `customers` SET `name` = '$name' ,`email` = '$email' ,`phone` = '$contact', `update_date` = '$addedDate' WHERE `id` = '$id' AND `active_status` ='1'";    
					$query=mysql_query($updt_user) or die(mysql_error());
					if(mysql_affected_rows()>0)
					{
						$response['message']  = "User Profile is successfully Update";
					    $response['msg_code'] = 1;
					}else{
                        $response['message']  = "User Profile is not Update.";
                    	$response['msg_code'] = 0;
                    }

			}else{ 
                
                $response['message']  = "Data is Missing.";
                $response['msg_code'] = 0; 
			}
			
               
             
            return json_encode($response);
		}    

/****************************SERVICE NO.5******************************************/
/*====================== FOR FORGOT PASSWORD =====================================*/    

        public function forgotPassword($service_data){

			$email = $service_data['email'];
	        if(filter_var($email, FILTER_VALIDATE_EMAIL) === false){
		
	        	$response['message'] = "Email is not valid";
				$response['msg_code'] = 0;
	   		}else{

	    		$sql   = "SELECT * FROM `customers` WHERE `email` = '$email'";
	    		$query =  mysql_query($sql) or die(mysql_error()); 
                if(mysql_num_rows($query)>0){
		            if($row=mysql_fetch_array($query)) {	
                        
                        $id          = $row['id'];
		    			$name        = $row['name'];
                        $code        = rand(1000, 9999);
                        $newpass     = md5($code);
						$sender_name = 'Impetrostock';

						$sql="UPDATE `customers` set password = '$newpass' where id ='$id'";
						$qq=mysql_query($sql);

						$sub = "Password Rest";
						$msg = "<p>Hi,".$name."</p>".
								"<p>Your Temp Password is ".$code."<br/></p>".
								"<p>Please Change<br/></p>".
								"<p>Best Regards,<br/>".$sender_name."</p>";
						$headers  = 'MIME-Version: 1.0' . "\r\n";
						$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
						$headers .=  "From: info@impetrosys.com";
						mail($email,$sub,$msg,$headers);
				
				       	$response['message'] = "Password mail is send to your mail id";
						$response['msg_code'] = 1;
		    		}
	    		}
	   			else {
	      			$response['message'] = "Please Enter Correct email";
					$response['msg_code'] = 0;
	    		}
	    	}
			return json_encode($response);
		}




/*******************************SERVICE NO.5**************************************/
/*======================FOR LIKE USER PROFILE=====================================*/    


	public function profile_likes($service_data){
       
       $user_id     = $service_data['user_id']; 
       $profile_id  = $service_data['profile_id']; 
       $from_userid = $service_data['from_userid']; 
       $date        = $this->default_datetime_zone();

       if(!empty($user_id) && !empty($profile_id) && !empty($from_userid)) {
       	
	       $sql = "SELECT * From `Mu_userLike` WHERE profile_id = '$profile_id' AND from_userid = '$from_userid' AND  id = '$user_id'";
	       $result = mysql_query($sql);
	       if(mysql_num_rows($result)>0){
	           
	            $response['message']  = "Already like.";
	            $response['msg_code'] = 0;

	       }else{

	       	    $int_like = "INSERT INTO `Mu_userLike`(`profile_id`,`from_userid`,`date`) VALUES ('$profile_id','$from_userid','$date')";
	       	    $run_int_like = mysql_query($int_like);
	       	    if(mysql_affected_rows()>0){
	               
	               $response['message']  = "Profile like";
	               $response['msg_code'] = 1;  
	       	    } 
	       }    
       }else{

                   $response['message']  = "Invailid Proccess";
	               $response['msg_code'] = 0;    
       }


             return json_encode($response);	 
    }


/*======================SERVICE NO.6-FOR BLOCKED USER ===========================*/    
/*********************************************************************************/

    public function Productlist($service_data){

        $userId = $service_data['userId'];
        $sql    = "SELECT * From `products`";
	    $result = mysql_query($sql);
	    if(mysql_num_rows($result)>0){
	        while ($row = mysql_fetch_array($result)){
	         
	          $id             = $row['id'];
	          $name           = $row['name'];
	          $price          = $row['price'];
	          $image          = $row['image'];
	          $category_id    = $row['category_id'];
	          $subcategory_id = $row['subcategory_id'];
	          $size           = $row['size'];
	          $unit           = $row['unit'];
	          $code           = $row['code'];
	          $quantity       = ($row['quantity'])?$row['quantity']:0;
	          $category_id    = $row['category_id'];
	          $subcategory_id = $row['subcategory_id'];
              $type           = $row['type'];
              $brand          = $row['brand']; 
              $description    = $row['description']; 
	          
              $catsql         = "SELECT * From `categories` WHERE `id`='$category_id'";
	          $catresult      = mysql_query($catsql);
	          if(mysql_num_rows($catresult)>0){
              $getname        = mysql_fetch_array($catresult);
              $categoryName   = $getname['name'];
              }
              $subsql         = "SELECT * From `subcategories` WHERE `id`='$subcategory_id'";
	          $subresult      = mysql_query($subsql);
	          if(mysql_num_rows($subresult)>0){
              $getname        = mysql_fetch_array($subresult);
              $subcategoryName   = $getname['name'];
              }
              
               $get_sql = "SELECT * From `wishlist` WHERE `productId`='$id' AND `userId`='$userId'";
               $get_result = mysql_query($get_sql);
               if(mysql_num_rows($get_result)>0){ $wishlist = '1'; }else{ $wishlist = '0'; }
              // 0 for => wishlist not added AND 1 for => product added wishlist

               $multi_image_data   = "SELECT * From `product_multi_image` WHERE `productId`='$id'";
               $multi_image_result = mysql_query($multi_image_data);
               if(mysql_num_rows($multi_image_result)>0){ 
               
               $multi_image_path = $this->product_image_path.'multiimage/'; 
               
               while($imageRow = mysql_fetch_array($multi_image_result)){
                

                $imageData[] = array( 'image' => $multi_image_path.$imageRow['image'] ); 

               }

               }else{

               	$imageData = array();
               	
               }

               $AttributeQuery    = "SELECT * From `product_fields_attributes` WHERE `productId`='$id'";
               $Attribute_result = mysql_query($AttributeQuery);
               if(mysql_num_rows($Attribute_result)>0){ 
               while($Attribute_row = mysql_fetch_array($Attribute_result)){
                

                $AttributeData[] = array(  $Attribute_row['attribute_key'] => $Attribute_row['attribute_value'] ); 

               }
               }else{

                $AttributeData = array(); 
               }
               
               $PR_EX_attribute    = "SELECT * From `product_attributes` WHERE `productId`='$id'";
               $PR_EX_result       = mysql_query($PR_EX_attribute);
               if(mysql_num_rows($PR_EX_result)>0){ 
               
               while($attribData   = mysql_fetch_array($PR_EX_result)){
                

                $Ex_Data[] = array( 
                	                  'attribute_id'    => $attribData['id'],  
                                      'product_code'    => $attribData['product_code'], 
                	                  'color'           => $attribData['product_color'],
                                      'size'            => $attribData['product_size'],
                                      'quantity'        => $attribData['product_quantity']
                                     
                                     ); 

               }

               }else{

               	$Ex_Data = array();
               	
               }


              $data[] = array( 'productId'      => $id,
                               'name'           => $name,
                               'price'          => $price,
                               'image'          => $this->product_image_path.$image,
                               'categoryName'   => $categoryName,
                               'subcategoryName'=> $subcategoryName,
                               'size'           => $size,
                               'unit'           => $unit,
                               'productcode'    => $code,
                               'quantity'       => $quantity,
                               'wishlist'       => $wishlist,
                               'categoryId'     => $category_id,
                               'subcategoryId'  => $subcategory_id,
                               'type'           => $type,
                               'brand'          => $brand, 
                               'description'    => $description, 
                               'multiimage'     => $imageData ,
                               'specification'  => $AttributeData,
                               'attribute'      => $Ex_Data  
                             );

              $imageData='';
              $AttributeData =''; 
              $Ex_Data ='';
              $response['message']  = "Product List";
	          $response['msg_code'] = 1;     
	          $response['data']     = $data;     
              
				
	          } 
 
	    }else{
             
             $response['message']  = "Product Data is Empty";
	         $response['msg_code'] = 0;     
        }

        return json_encode($response);	 

    }

/*===================== SERVICE NO.6-FOR PRODUCT INFO BY ID ===========================*/    
/*********************************************************************************/

    public function ProductinfoBYid($service_data){

        $userId    = $service_data['userId'];
        $productId = $service_data['productId'];
        
        $sql       = "SELECT * From `products` WHERE `id`='$productId'";
	    $result = mysql_query($sql);
	    if(mysql_num_rows($result)>0){
	        while ($row = mysql_fetch_array($result)){
	         
	          $id             = $row['id'];
	          $name           = $row['name'];
	          $price          = $row['price'];
	          $image          = $row['image'];
	          $category_id    = $row['category_id'];
	          $subcategory_id = $row['subcategory_id'];
	          $size           = $row['size'];
	          $unit           = $row['unit'];
	          $code           = $row['code'];
	          $quantity       = ($row['quantity'])?$row['quantity']:0;
	          $category_id    = $row['category_id'];
	          $subcategory_id = $row['subcategory_id'];
              $type           = $row['type'];
              $brand          = $row['brand'];
              $description    = $row['description'];   
	          
              $catsql         = "SELECT * From `categories` WHERE `id`='$category_id'";
	          $catresult      = mysql_query($catsql);
	          if(mysql_num_rows($catresult)>0){
              $getname        = mysql_fetch_array($catresult);
              $categoryName   = $getname['name'];
              }
              $subsql         = "SELECT * From `subcategories` WHERE `id`='$subcategory_id'";
	          $subresult      = mysql_query($subsql);
	          if(mysql_num_rows($subresult)>0){
              $getname        = mysql_fetch_array($subresult);
              $subcategoryName   = $getname['name'];
              }
              
               $get_sql = "SELECT * From `wishlist` WHERE `productId`='$id' AND `userId`='$userId'";
               $get_result = mysql_query($get_sql);
               if(mysql_num_rows($get_result)>0){ $wishlist = '1'; }else{ $wishlist = '0'; }
              // 0 for => wishlist not added AND 1 for => product added wishlist

               $multi_image_data   = "SELECT * From `product_multi_image` WHERE `productId`='$id'";
               $multi_image_result = mysql_query($multi_image_data);
               if(mysql_num_rows($multi_image_result)>0){ 
               
               $multi_image_path = $this->product_image_path.'multiimage/'; 
               while($imageRow = mysql_fetch_array($multi_image_result)){
                

                $imageData[] = array( 'image' => $multi_image_path.$imageRow['image'] ); 

               }
               }else{

               	$imageData = array();
               	
               }

               $AttributeQuery    = "SELECT * From `product_fields_attributes` WHERE `productId`='$id'";
               $Attribute_result = mysql_query($AttributeQuery);
               if(mysql_num_rows($Attribute_result)>0){ 
               while($Attribute_row = mysql_fetch_array($Attribute_result)){
                

                $AttributeData[] = array(  $Attribute_row['attribute_key'] => $Attribute_row['attribute_value'] ); 

               }
               }else{

                $AttributeData = array(); 
               }
               
               $PR_EX_attribute    = "SELECT * From `product_attributes` WHERE `productId`='$id'";
               $PR_EX_result       = mysql_query($PR_EX_attribute);
               if(mysql_num_rows($PR_EX_result)>0){ 
               
               while($attribData   = mysql_fetch_array($PR_EX_result)){
                

                $Ex_Data[] = array( 
                	                  'attribute_id'    => $attribData['id'],  
                                      'product_code'    => $attribData['product_code'], 
                	                  'color'           => $attribData['product_color'],
                                      'size'            => $attribData['product_size'],
                                      'quantity'        => $attribData['product_quantity']
                                     
                                     ); 

               }

               }else{

               	$Ex_Data = array();
               	
               } 
                  
              $data[] = array( 'productId'      => $id,
                               'name'           => $name,
                               'price'          => $price,
                               'image'          => $this->product_image_path.$image,
                               'categoryName'   => $categoryName,
                               'subcategoryName'=> $subcategoryName,
                               'size'           => $size,
                               'unit'           => $unit,
                               'productcode'    => $code,
                               'quantity'       => $quantity,
                               'wishlist'       => $wishlist,
                               'categoryId'     => $category_id,
                               'subcategoryId'  => $subcategory_id,
                               'type'           => $type,
                               'brand'          => $brand, 
                               'description'    => $description, 
                               'multiimage'     => $imageData ,
                               'specification'  => $AttributeData,
                               'attribute'      => $Ex_Data  
                             );

              $imageData ='';
              $AttributeData =''; 
              $Ex_Data ='';
              $response['message']  = "Product List";
	          $response['msg_code'] = 1;     
	          $response['data']     = $data;     
              
				
	          } 
 
	    }else{
             
             $response['message']  = "Product Data is Empty";
	         $response['msg_code'] = 0;     
        }

        return json_encode($response);

    }

/*====================== SERVICE NO.8-FOR ADD PRODUCT INTO WISHLIST ===========================*/    
/*************************************************************************************/

    public function add_wishlist($service_data){
       
       $addedDate  = $this->default_datetime_zone();
       $productId  = $service_data['productId']; 
       $userId     = $service_data['userId'];

       $addsql         = "SELECT * From `wishlist` WHERE `productId`='$productId' AND `userId`='$userId'";
       $wishlistresult = mysql_query($addsql);
       if(mysql_num_rows($wishlistresult)>0){

            $response['message']  = "This Product Already Added";
	        $response['msg_code'] = 0;       

       }else{

            $add_query  = "INSERT INTO wishlist (`productId`,`userId`,`create_date`) VALUES ('$productId','$userId','$addedDate')"; 
	       $runquery   = mysql_query($add_query) or die(mysql_error());
		   if(mysql_affected_rows()>0){
		               
		        $response['message']  = "Add Product successfully";
		        $response['msg_code'] = 1;  

		    }else{

	            $response['message']  = "Product Not Added";
		        $response['msg_code'] = 0;  

		    } 
       }

       return json_encode($response);	  	 
        
    }

/*====================== SERVICE NO.9-FOR REMOVE PRODUCT INTO WISHLIST ===========================*/    
/*************************************************************************************/

    public function remove_wishlist($service_data){
       
       
       $productId  = $service_data['productId']; 
       $userId     = $service_data['userId'];

       $addsql         = "SELECT * From `wishlist` WHERE `productId`='$productId' AND `userId`='$userId'";
       $wishlistresult = mysql_query($addsql);
       if(mysql_num_rows($wishlistresult)>0){
            
            $row = mysql_fetch_array($wishlistresult); 
            $review_id = $row['id'];
            $sql_d = "DELETE FROM wishlist WHERE id='$review_id'";
            if(mysql_query($sql_d)) {
                
                $response['message']  = "Remove Product Successfully";
	            $response['msg_code'] = 1;         

			}else{

			    $response['message']  = "Remove Product Fail";
	            $response['msg_code'] = 0;         
			}

            
        }else{

            $response['message']  = "This Product is Already Remove";
	        $response['msg_code'] = 0;          
       }

       return json_encode($response);	  	 
        
    }    
/*====================== SERVICE NO.10-FOR USER WISHLIST ===========================*/    
/*************************************************************************************/

    public function user_wishlist($service_data){

        $userId = $service_data['userId'];
        if($userId){
            $sql    = "SELECT * From `customers` WHERE `id`='$userId' AND `active_status` = '1'";
            $result = mysql_query($sql);
            if(mysql_num_rows($result)>0){
            
            $sql_w     = "SELECT * From `wishlist` WHERE `userId`='$userId'";
            $result_w  = mysql_query($sql_w);
            if(mysql_num_rows($result_w)>0){
            	
            while($row = mysql_fetch_array($result_w)){
            $productId = $row['productId'];
            
            $sql       = "SELECT * From `products` WHERE `id`='$productId'";
		    $result = mysql_query($sql);
		    if(mysql_num_rows($result)>0){
		        while ($row = mysql_fetch_array($result)){
		         
		          $id             = $row['id'];
		          $name           = $row['name'];
		          $price          = $row['price'];
		          $image          = $row['image'];
		          $category_id    = $row['category_id'];
		          $subcategory_id = $row['subcategory_id'];
		          $size           = $row['size'];
		          $unit           = $row['unit'];
		          $code           = $row['code'];
		          $quantity       = ($row['quantity'])?$row['quantity']:0;
		          $category_id    = $row['category_id'];
		          $subcategory_id = $row['subcategory_id'];
		          $type           = $row['type'];
		          $brand          = $row['brand'];  
		          $description    = $row['description'];  
		          
		          $catsql         = "SELECT * From `categories` WHERE `id`='$category_id'";
		          $catresult      = mysql_query($catsql);
		          if(mysql_num_rows($catresult)>0){
		          $getname        = mysql_fetch_array($catresult);
		          $categoryName   = $getname['name'];
		          }
		          $subsql         = "SELECT * From `subcategories` WHERE `id`='$subcategory_id'";
		          $subresult      = mysql_query($subsql);
		          if(mysql_num_rows($subresult)>0){
		          $getname        = mysql_fetch_array($subresult);
		          $subcategoryName   = $getname['name'];
		          }
		          
		           $get_sql = "SELECT * From `wishlist` WHERE `productId`='$id' AND `userId`='$userId'";
		           $get_result = mysql_query($get_sql);
		           if(mysql_num_rows($get_result)>0){ $wishlist = '1'; }else{ $wishlist = '0'; }
		          // 0 for => wishlist not added AND 1 for => product added wishlist

		           $multi_image_data   = "SELECT * From `product_multi_image` WHERE `productId`='$id'";
		           $multi_image_result = mysql_query($multi_image_data);
		           if(mysql_num_rows($multi_image_result)>0){ 
		           
		           $multi_image_path = $this->product_image_path.'multiimage/'; 
		           while($imageRow = mysql_fetch_array($multi_image_result)){
		            

		            $imageData[] = array( 'image' => $multi_image_path.$imageRow['image'] ); 

		           }
		           }else{

		           	$imageData = array();
		           	
		           }

		           $AttributeQuery    = "SELECT * From `product_fields_attributes` WHERE `productId`='$id'";
		           $Attribute_result = mysql_query($AttributeQuery);
		           if(mysql_num_rows($Attribute_result)>0){ 
		           while($Attribute_row = mysql_fetch_array($Attribute_result)){
		            

		            $AttributeData[] = array(  $Attribute_row['attribute_key'] => $Attribute_row['attribute_value'] ); 

		           }
		           }else{

		            $AttributeData = array(); 
		           }
		           
		           $PR_EX_attribute    = "SELECT * From `product_attributes` WHERE `productId`='$id'";
	               $PR_EX_result       = mysql_query($PR_EX_attribute);
	               if(mysql_num_rows($PR_EX_result)>0){ 
	               
	               while($attribData   = mysql_fetch_array($PR_EX_result)){
	                

	                $Ex_Data[] = array( 
	                	                  'attribute_id'    => $attribData['id'],  
	                                      'product_code'    => $attribData['product_code'], 
	                	                  'color'           => $attribData['product_color'],
	                                      'size'            => $attribData['product_size'],
	                                      'quantity'        => $attribData['product_quantity']
	                                     
	                                     ); 

	               }

	               }else{

	               	$Ex_Data = array();
	               	
	               } 
	               


		          $data[] = array( 'productId'      => $id,
		                           'name'           => $name,
		                           'price'          => $price,
		                           'image'          => $this->product_image_path.$image,
		                           'categoryName'   => $categoryName,
		                           'subcategoryName'=> $subcategoryName,
		                           'size'           => $size,
		                           'unit'           => $unit,
		                           'productcode'    => $code,
		                           'quantity'       => $quantity,
		                           'wishlist'       => $wishlist,
		                           'categoryId'     => $category_id,
		                           'subcategoryId'  => $subcategory_id,
		                           'type'           => $type,
		                           'brand'          => $brand, 
		                           'description'    => $description, 
		                           'multiimage'     => $imageData ,
		                           'specification'  => $AttributeData,
		                           'attribute'      => $Ex_Data  
		                         );

		          $imageData='';
		          $AttributeData =''; 
		          $Ex_Data = '';
		          $response['message']  = "Product List";
		          $response['msg_code'] = 1;     
		          $response['data']     = $data;     
		          
					
		          } 

		    }


            }       
            }else{
		         
		         $response['message']  = "Product Data is Empty";
		         $response['msg_code'] = 0;     
		    }      
               
            }else{

                $response['message']  = "Please login First";
		        $response['msg_code'] = 0;    

            }
        	
        }else{
          
            $response['message']  = "errer";
		    $response['msg_code'] = 0;  
        }
        
        return json_encode($response);	  	 
    }   

/*====================== SERVICE NO.11-FOR ADD PRODUCT REVIEW ===========================*/    
/*************************************************************************************/

    public function user_review($service_data){
        
        $addedDate    = $this->default_datetime_zone();
	    $documentpath = $this->upload_image_path;
        $userId    = $service_data['userId'];
        $productId = $service_data['productId'];
        $review    = $service_data['review'];

        if($userId){
            $sql    = "SELECT * From `customers` WHERE `id`='$userId' AND `active_status` = '1'";
            $result = mysql_query($sql);
            if(mysql_num_rows($result)>0){
            
            $add_query  = "INSERT INTO review (`productId`,`userId`,`review`,`create_date`) VALUES ('$productId','$userId','$review','$addedDate')"; 
	        $runquery   = mysql_query($add_query) or die(mysql_error());
		    if(mysql_affected_rows()>0){ 

              $response['message']  = "Add Review Successfully";
		      $response['msg_code'] = 1;    
            }else{
              
              $response['message']  = "Review Not Added";
		      $response['msg_code'] = 0;  

            }   
            }
        }else{
            
            $response['message']  = "errer";
		    $response['msg_code'] = 0;  

        }      

        return json_encode($response);	  	 
    } 

/*====================== SERVICE NO.12-FOR PRODUCT REVIEW LIST =======================*/    
/*************************************************************************************/

    public function ProductReviewlist($service_data){
        
        $productId    = $service_data['productId'];
        if($productId){

            $sql    = "SELECT * From `review` WHERE `productId`='$productId'";
            $result = mysql_query($sql);
            if(mysql_num_rows($result)>0){
            while($row = mysql_fetch_array($result)){
            $userId = $row['userId']; 
            $review = $row['review'];	
            $date   = $row['create_date'];	
            
            $sql_r    = "SELECT * From `customers` WHERE `id`='$userId'";
            $result_r = mysql_query($sql_r);
            if(mysql_num_rows($result_r)>0){
            	
            $row1 = mysql_fetch_array($result_r);
            $customerName = $row1['name'];  
            }

            $sql_rt    = "SELECT * From `rating` WHERE `userId`='$userId' AND `productId`='$productId'";
            $result_rt = mysql_query($sql_rt);
            if(mysql_num_rows($result_rt)>0){
            
            $row_rt = mysql_fetch_array($result_rt);
            $rating = $row_rt['rating'];  

            }else{
            
            $rating = '0';  

            }
            $data[] = array('rating' => $rating, 'review' => $review, 'customerName' => $customerName, 'date' => $date); 
            }

            $response['message']  = "Review List";
		    $response['msg_code'] = 1;                           
		    $response['data']     = $data;                           

            }else{

            $response['message']  = "No Review";
		    $response['msg_code'] = 0;  

            }
        }else{

            $response['message']  = "errer";
		    $response['msg_code'] = 0;  
        }
        return json_encode($response);	  	         
    } 
/*====================== SERVICE NO.13-FOR RELATED PRODUCT LIST ===========================*/    
/*************************************************************************************/

    public function ralatedProductlist($service_data){
        
        $categoryId    = $service_data['categoryId'];
        $subcategoryId = $service_data['subcategoryId'];
        $userId        = $service_data['userId']; 

        if($categoryId || $subcategoryId){
            
           $sql  = "SELECT * From `products` WHERE `category_id`='$categoryId' AND `subcategory_id`='$subcategoryId'";
	        $result     = mysql_query($sql);
	        if(mysql_num_rows($result)>0){

	              $row = mysql_fetch_array($result);
	              $id              = $row['id'];
		          $name            = $row['name'];
		          $price           = $row['price'];
		          $image           = $row['image'];
		          $categoryName    = $row['category_id'];
		          $subcategoryName = $row['subcategory_id'];
		          $size            = $row['size'];
		          $unit            = $row['unit'];
		          $code            = $row['code'];
		          $quantity        = ($row['quantity'])?$row['quantity']:0;
		          $category_id     = $row['category_id'];
		          $subcategory_id  = $row['subcategory_id'];
		          $type            = $row['type'];
		          $brand           = $row['brand'];
		          $price           = $row['price'];
		          $description     = $row['description'];

		          $catsql         = "SELECT * From `categories` WHERE `id`='$category_id'";
	              $catresult      = mysql_query($catsql);
	              if(mysql_num_rows($catresult)>0){
	              $getname        = mysql_fetch_array($catresult);
	              $categoryName   = $getname['name'];
	              }
	              $subsql         = "SELECT * From `subcategories` WHERE `id`='$subcategory_id'";
	              $subresult      = mysql_query($subsql);
	              if(mysql_num_rows($subresult)>0){
	              $getname        = mysql_fetch_array($subresult);
	              $subcategoryName   = $getname['name'];
	              }

	           	$multi_image_data   = "SELECT * From `product_multi_image` WHERE `productId`='$id'";
                $multi_image_result = mysql_query($multi_image_data);
                if(mysql_num_rows($multi_image_result)>0){ 
                
                $multi_image_path = $this->product_image_path.'multiimage/'; 
                while($imageRow = mysql_fetch_array($multi_image_result)){
                

                 $imageData[] = array( 'image' => $multi_image_path.$imageRow['image'] ); 

                }
                }else{

                 $imageData = array(); 

                }

                $AttributeQuery    = "SELECT * From `product_fields_attributes` WHERE `productId`='$id'";
                $Attribute_result = mysql_query($AttributeQuery);
                if(mysql_num_rows($Attribute_result)>0){ 
                while($Attribute_row = mysql_fetch_array($Attribute_result)){
                

                 $AttributeData[] = array(  $Attribute_row['attribute_key'] => $Attribute_row['attribute_value'] ); 

                }
                }else{

                 $AttributeData = array(); 
                }
	            
	              $get_sql = "SELECT * From `wishlist` WHERE `productId`='$id' AND `userId`='$userId'";
	              $get_result = mysql_query($get_sql);
	              if(mysql_num_rows($get_result)>0){ $wishlist = '1'; }else{ $wishlist = '0'; }

	              $data[] = array( 'productId'       => $id,
	                               'name'            => $name,
	                               'image'           => $this->product_image_path.$image,
	                               'categoryName'    => $categoryName,
	                               'subcategoryName' => $subcategoryName,
	                               'price'           => $price,
	                               'size'            => $size,
	                               'description'     => $description,
	                               'unit'            => $unit,
	                               'productcode'     => $code,
	                               'quantity'        => $quantity,
	                               'wishlist'        => $wishlist,
	                               'categoryId'      => $category_id,
	                               'subcategoryId'   => $subcategory_id,
	                               'type'            => $type,
	                               'brand'           => $brand,
	                               'multiimage'     => $imageData ,
                                   'specification'  => $AttributeData 

	                             );
                $imageData  ='';
                $AttributeData =''; 
	            $response['message']  = "Related Product List";
		        $response['msg_code'] = 1;         
		        $response['data'] = $data;         

	        }else{
	           
	            $response['message']  = "No Product Data";
		        $response['msg_code'] = 0;         
	        }     
            

        }else{

            $response['message']  = "errer";
		    $response['msg_code'] = 0;  
        }

        return json_encode($response);	  	                 
    }                       
/*====================== SERVICE NO.14-FOR PLACE ORDER  ===========================*/    
/******************************************************************************************/

	public function placeOrder($service_data)
	        {
	             
	            $userId       = $service_data['userId'];
	            $orderNumber  = $service_data['orderNumber'];
	            $totalAmount  = $service_data['totalAmount'];
	            $totalItems   = $service_data['totalItem'];
	            $paymentType  = $service_data['paymentType'];
                #FOR PRODUCT BUCKET DATA
	            $CartData    = $service_data['productData'];
	            $sql = "INSERT INTO `orders`(`Bill_Number` ,`CustomerId` ,`TotalPrice` ,`TotalQty`) VALUES ('$orderNumber' ,'$userId','$totalAmount' ,'$totalItems')";
                $query    = mysql_query($sql) or die(mysql_error());
	            $orderId  = mysql_insert_id();
                if(mysql_affected_rows()>0) {

	            foreach($CartData as $BucketData){

                    $order_id      = $orderId;
	                $productId     = $BucketData['id'];       
	                $price         = $BucketData['price'];
			        $quantity      = $BucketData['quantity'];
			        $gross_total   = $BucketData['totalItemPrice'];
			    
			    $querySql  = "INSERT INTO `order_detail`(`orderId`, `price`, `ItemId`, `quantity` , `gross_total` ,`OrderDate`) VALUES ('$order_id' ,'$price' ,'$productId' ,'$quantity' ,'$gross_total' ,'$addedDate')";
                $resultSql = mysql_query($querySql) or die(mysql_error());
	                       
	            }
	                $response['message']     = "Order is Successfully added";
	                $response['msg_code']    = 1;
	                
	            }else{
	            	
	                $response['message'] = "Order Is Not Added";
	                $response['msg_code'] = 0;
	            }
	                       
	            return json_encode($response);
	        }

/*====================== SERVICE NO.15-FOR CHANGE PASSWORD ===========================*/    
/******************************************************************************************/

	public function ChangePassword($service_data){
	             
	    $userId       = $service_data['userId'];
	    $oldPassword  = $service_data['oldPassword'];
	    $mdPassword   = md5($oldPassword);
	    $newPassword  = $service_data['newPassword'];
        $newmdPassrd  = md5($newPassword);

	    $sql = "SELECT * From `customers` WHERE `id`='$userId' AND `password`='$mdPassword'";
	    $result = mysql_query($sql);
	    if(mysql_num_rows($result)>0){
	        $pass_sql = "UPDATE `customers` SET `password`='$newmdPassrd' WHERE `id`='$userId'";
            $pass_result = mysql_query($pass_sql);
            if(mysql_affected_rows()>0){
              
              $response['message'] = "Password Changed Successfully";
	          $response['msg_code'] = 1;

            }else{
              
              $response['message'] = "Password Not Change ,Please Try Agian ";
	          $response['msg_code'] = 0;

            }
	    }else{

            $response['message'] = "Old Password Not Matched";
	        $response['msg_code'] = 0;
	    }

	    return json_encode($response);
	}

/*======================SERVICE NO.16-FOR NEW RELEASE PRODUCT ===========================*/    
/*********************************************************************************/

    public function NewReleaseProduct($service_data){

        $userId = $service_data['userId'];
        $sql    = "SELECT * FROM `products` ORDER BY `id` DESC LIMIT 10";
	    $result = mysql_query($sql);
	    if(mysql_num_rows($result)>0){
	        while ($row = mysql_fetch_array($result)){
	         
	          $id             = $row['id'];
	          $name           = $row['name'];
	          $price          = $row['price'];
	          $image          = $row['image'];
	          $category_id    = $row['category_id'];
	          $subcategory_id = $row['subcategory_id'];
	          $size           = $row['size'];
	          $unit           = $row['unit'];
	          $code           = $row['code'];
	          $quantity       = $row['quantity'];

	          $catsql         = "SELECT * From `categories` WHERE `id`='$category_id'";
	          $catresult      = mysql_query($catsql);
	          if(mysql_num_rows($catresult)>0){
              $getname        = mysql_fetch_array($catresult);
              $categoryName   = $getname['name'];
              }
              $subsql         = "SELECT * From `subcategories` WHERE `id`='$subcategory_id'";
	          $subresult      = mysql_query($subsql);
	          if(mysql_num_rows($subresult)>0){
              $getname        = mysql_fetch_array($subresult);
              $subcategoryName   = $getname['name'];
              }
              
               $get_sql = "SELECT * From `wishlist` WHERE `productId`='$id' AND `userId`='$userId'";
               $get_result = mysql_query($get_sql);
               if(mysql_num_rows($get_result)>0){ $wishlist = '1'; }else{ $wishlist = '0'; }
              // 0 for => wishlist not added AND 1 for => product added wishlist
              $data[] = array( 'productId'      => $id,
                               'name'           => $name,
                               'image'          => $this->product_image_path.$image,
                               'categoryName'   => $categoryName,
                               'subcategoryName'=> $subcategoryName,
                               'size'           => $size,
                               'unit'           => $unit,
                               'productcode'    => $code,
                               'quantity'       => $quantity,
                               'wishlist'       => $wishlist
                               
                             );

              $response['message']  = "Product List";
	          $response['msg_code'] = 1;     
	          $response['data']     = $data;     

				
	          } 
 
	    }else{
             
             $response['message']  = "Product Data is Empty";
	         $response['msg_code'] = 0;     
        }

        return json_encode($response);	 

    }	
/************************    SERVICE NO. 17**************************/
/*====================== PRODUCT RATING =========================*/    


public function ProductRating($service_data){
    
    $productId = $service_data['productId'];
    $rating    = $service_data['rating'];
    $userId    = $service_data['userId'];
    $date      = $this->default_datetime_zone(); 
    
    $sql   = "SELECT * FROM `customers` WHERE `id` = '$userId' AND `active_status` = '1'";
	$query =  mysql_query($sql) or die(mysql_error()); 
    if(mysql_num_rows($query)>0){

	    $sql1       = "SELECT * From `rating` WHERE `userId`='$userId' AND `productId`='$productId'";
		$result1    =  mysql_query($sql1);
		if(mysql_num_rows($result1)>0){
	        
	        $response['message']  = "This User Already Rated This Product";
		    $response['msg_code'] = 0;     

        }else{
            
            $querySql  = "INSERT INTO `rating`(`rating`,`userId`,`productId`,`date`) VALUES ('$rating','$userId','$productId','$date')";
            $resultSql = mysql_query($querySql) or die(mysql_error());
            if($resultSql){
	          
	            $response['message']  = "Rating Add Successfully";
		        $response['msg_code'] = 1;           

	        }else{
	            
	            $response['message']  = "There is Some Problem , please Try after Some Time";
		        $response['msg_code'] = 0;         
	        }

	    }
    
    }else{

        $response['message']  = "Plaese Login First";
	    $response['msg_code'] = 0;       
    }

    return json_encode($response);	 
}

/************************    SERVICE NO. 18**************************/
/*====================== USER ORDER LIST =========================*/

	public function UserOrderList($service_data){
        
        $userId = $service_data['userId']; 
        if(!empty($userId)){
        
            $sql    = "SELECT * FROM `customers` WHERE `id` = '$userId' AND `active_status` = '1'";
		    $query  =  mysql_query($sql) or die(mysql_error()); 
	        if(mysql_num_rows($query)>0){    
                
                $sql_order    = "SELECT * FROM `orders` WHERE `CustomerId` = '$userId'";
		        $query_order  =  mysql_query($sql_order) or die(mysql_error()); 
	            if(mysql_num_rows($query_order)>0){      
                   while ($row  = mysql_fetch_array($query_order)){
                   $orderId     = $row['id'];
                   $Bill_Number = $row['Bill_Number']; 
                   $CustomerId  = $row['CustomerId']; 
                   $TotalQty    = $row['TotalQty']; 
                   $TotalPrice  = $row['TotalPrice']; 
                   $OrderDate   = $row['OrderDate']; 
                   $status      = $row['status']; 
                   if($status==0){
                   	$orderstatus = "Pendding";
                   }elseif($status==1){
                   	$orderstatus = "Proccess";  
                   }elseif ($status==2){
                   	$orderstatus = "Delivered";
                   }
                    
                    $sql_detail    = "SELECT * FROM `order_detail` WHERE `orderId` = '$orderId'";
		            $query_detail  =  mysql_query($sql_detail) or die(mysql_error()); 
	                if(mysql_num_rows($query_detail)>0){      
                    while($row1  = mysql_fetch_array($query_detail)){
                        
                       $productId  = $row1['ItemId'];    
                       $price      = $row1['price'];    
                       $quantity   = $row1['quantity'];  

                       $sql_pr        = "SELECT * From `products` WHERE `id`='$productId'";
                       $result_pr     = mysql_query($sql_pr);
                       if(mysql_num_rows($result_pr)>0){
                       $row_pr = mysql_fetch_array($result_pr);
                       
                          
				          $name            = $row_pr['name'];
				          $price           = $row_pr['price'];
				          $image           = $row_pr['image'];
				          $categoryName    = $row_pr['category_id'];
				          $subcategoryName = $row_pr['subcategory_id'];
				          $size            = $row_pr['size'];
				          $unit            = $row_pr['unit'];
				          $code            = $row_pr['code']; 
                       } 
                       $orderData[]  = array( 'price' => $price, 'productId' => $productId,'quantity' => $quantity);
                    } 
                    $data[] = array( 
	                   	            'orderId'     => $orderId,
                   	                'orderNumber' => $Bill_Number,
                   	                'TotalQty'    => $TotalQty,
                   	                'orderId'     => $orderId,
                   	                'TotalPrice'  => $TotalPrice,
                   	                'OrderDate'   => $OrderDate,
                   	                'orderstatus' => $orderstatus, 
                   	                'orderData'   => $orderData

	                   	           );                           
                    $orderData = '';    
                    }
                    } 
                    $response['message']  = "Order List";
	                $response['msg_code'] = 1;
	                $response['data']     = $data;
                }else{
                    
                    $response['message']  = "No order Yet";
	                $response['msg_code'] = 0;        
   	            }
	               
	        }else{

                $response['message']  = "Please login First";
	            $response['msg_code'] = 0;       
            }
	    }else{

            $response['message']  = "Data Missing";
	        $response['msg_code'] = 0;       
        }

        return json_encode($response);	 

	}

/*********************************************************************/
/*================SERVICE NO.19 -FOR EDIT USER iMAGE=======================*/

    function editUserImage($service_data)
		{
			
            $addedDate    = $this->default_datetime_zone();
			$documentpath = $this->upload_image_path;
			$id           = $service_data['userId'];
		    $image        = $service_data['image'];
			
            if(!empty($image)){ 
				   
							$filename1 = md5(time()).'.jpg';
							$base1=$image;
							$binary1 = base64_decode($base1);         
							header('Content-Type: bitmap; charset=utf-8');
							$file1 = fopen($documentpath.$filename1,  'wb');
							$addImages1=$filename1;
							fwrite($file1, $binary1);
							fclose($file1);
				  
			}
			
			$image = (!empty($addImages1))?$addImages1:('default.jpg'); 
            	
                    $updt_user = "UPDATE `customers` SET `image` = '$image' ,`update_date` = '$addedDate' WHERE `id` = '$id' AND `active_status` ='1'";    
					$query     = mysql_query($updt_user) or die(mysql_error());
					if(mysql_affected_rows()>0)
					{

						$sql1 = "SELECT * From customers WHERE id = '$id'";
	                    $result2 = mysql_query($sql1);
					    if(mysql_num_rows($result2)>0){
	                    $row=mysql_fetch_array($result2);

	                    $data[] = array('userId'=>$row['id'], 'image'=>$this->image_path.$row['image']);   

	                    }

						$response['message'] ="User Profile image is successfully Update";
					    $response['msg_code']=1;
					    $response['data']    =$data;

					}else{
                        $response['message']="User Profile image is not Update.";
                    	$response['msg_code']=0;
                    }
               
             
            return json_encode($response);
		}	

/*********************************************************************/
/*================SERVICE NO.19 -FOR EDIT USER iMAGE=======================*/

    function getCategories(){
      
      
      $category = "SELECT * FROM `categories`"; 
      $query    = mysql_query($category);
      if(mysql_num_rows($query)>0){
      while($rows = mysql_fetch_array($query)){

        $categoryId = $rows['id'];
        $subcategory = "SELECT * FROM `subcategories` WHERE category_id = '$categoryId' LIMIT 8"; 
        $subquery    = mysql_query($subcategory);
        if(mysql_num_rows($subquery)>0){

        while($row = mysql_fetch_array($subquery)){
            
            $subCategoryData[] = array( 'subcategoryName' => $row['name'],'subcategoryId' => $row['id']); 
            
        }

        $CategoryData[]  = array( 'categoryName' => $rows['name'],'categoryId' => $rows['id'],'subcategoryData' => $subCategoryData);   
        $subCategoryData = '';      
        }

        
      }
      
        $response['message']  = "Category List";
		$response['msg_code'] = 1;
		$response['data']     = $CategoryData;  
      }
      
      return json_encode($response); 
	}

/*======================SERVICE NO.21-FOR FILTTER PRODUCT ACCORDING TO TYPE ===========================*/    
/*********************************************************************************/

    public function Filtter_Product($service_data){

        $userId = $service_data['userId'];
        $type = $service_data['type'];
        if(!empty($type)){
        $sql    = "SELECT * From `products` where type='$type'";
	    $result = mysql_query($sql);
		    if(mysql_num_rows($result)>0){
		        while ($row = mysql_fetch_array($result)){
		          
		            
		          $id             = $row['id'];
		          $name           = $row['name'];
		          $price          = $row['price'];
		          $image          = $row['image'];
		          $category_id    = $row['category_id'];
		          $subcategory_id = $row['subcategory_id'];
		          $size           = $row['size'];
		          $unit           = $row['unit'];
		          $code           = $row['code'];
		          $quantity       = $row['quantity'];
		          $category_id    = $row['category_id'];
		          $subcategory_id = $row['subcategory_id'];
	              $type           = $row['type']; 
	              $brand          = $row['brand']; 
		          
	              $catsql         = "SELECT * From `categories` WHERE `id`='$category_id'";
		          $catresult      = mysql_query($catsql);
		          if(mysql_num_rows($catresult)>0){

	              $getname        = mysql_fetch_array($catresult);
	              $categoryName   = $getname['name'];

	              }
	              $subsql         = "SELECT * From `subcategories` WHERE `id`='$subcategory_id'";
		          $subresult      = mysql_query($subsql);
		          if(mysql_num_rows($subresult)>0){
	              $getname        = mysql_fetch_array($subresult);
	              $subcategoryName   = $getname['name'];
	              }
	              
	               $get_sql = "SELECT * From `wishlist` WHERE `productId`='$id' AND `userId`='$userId'";
	               $get_result = mysql_query($get_sql);
	               if(mysql_num_rows($get_result)>0){ $wishlist = '1'; }else{ $wishlist = '0'; }
	              // 0 for => wishlist not added AND 1 for => product added wishlist

	               $multi_image_data   = "SELECT * From `product_multi_image` WHERE `productId`='$id'";
	               $multi_image_result = mysql_query($multi_image_data);
	               if(mysql_num_rows($multi_image_result)>0){ 
	               
	               $multi_image_path = $this->product_image_path.'multiimage/'; 
	               while($imageRow = mysql_fetch_array($multi_image_result)){
	                

	                $imageData[] = array( 'image' => $multi_image_path.$imageRow['image'] ); 

	               }
	               }else{

	                $imageData = array(); 

	               }

	               $AttributeQuery    = "SELECT * From `product_fields_attributes` WHERE `productId`='$id'";
	               $Attribute_result = mysql_query($AttributeQuery);
	               if(mysql_num_rows($Attribute_result)>0){ 
	               while($Attribute_row = mysql_fetch_array($Attribute_result)){
	                

	                $AttributeData[] = array(  $Attribute_row['attribute_key'] => $Attribute_row['attribute_value'] ); 

	               }
	               }else{

	                $AttributeData = array(); 
	               }

	             	$productdata[] = array( 

	              	               'productId'      => $id,
	                               'name'           => $name,
	                               'price'          => $price,
	                               'image'          => $this->product_image_path.$image,
	                               'categoryName'   => $categoryName,
	                               'subcategoryName'=> $subcategoryName,
	                               'size'           => $size,
	                               'unit'           => $unit,
	                               'productcode'    => $code,
	                               'quantity'       => $quantity,
	                               'wishlist'       => $wishlist,
	                               'categoryId'     => $category_id,
	                               'subcategoryId'  => $subcategory_id,
	                               'type'           => $type,
	                               'brand'          => $brand,
	                               'multiimage'     => $imageData,
	                               'specification'  => $AttributeData
	                               
	                             );
	                            $imageData     ='';
	                            $AttributeData ='';    
		        

					
		  		} 
	              
		          $data = $productdata; 
	              $response['message']  = "Product List";
		          $response['msg_code'] = 1;     
		          $response['data']     = $data;       
	 
		    }else{
	             
	             $response['message']  = "Product Data is Empty";
		         $response['msg_code'] = 0;     
	        }
        }else{
             
             $response['message']  = "Please set type";
	         $response['msg_code'] = 0;     
        }
        return json_encode($response);	 

    }


/*======================SERVICE NO.21-FOR FILTTER PRODUCT ACCORDING TO TYPE ===========================*/    
/*********************************************************************************/

    public function Filtter_ProductByType($service_data){

        $userId = $service_data['userId'];
        $sql    = "SELECT * From `products`";
	    $result = mysql_query($sql);
	    if(mysql_num_rows($result)>0){
	        while ($row = mysql_fetch_array($result)){
	          
	        if($row['type']=='1'){
	          $id             = $row['id'];
	          $name           = $row['name'];
	          $price          = $row['price'];
	          $image          = $row['image'];
	          $category_id    = $row['category_id'];
	          $subcategory_id = $row['subcategory_id'];
	          $size           = $row['size'];
	          $unit           = $row['unit'];
	          $code           = $row['code'];
	          $quantity       = ($row['quantity'])?$row['quantity']:0;
	          $category_id    = $row['category_id'];
	          $subcategory_id = $row['subcategory_id'];
              $type           = $row['type']; 
              $brand          = $row['brand']; 
              $description    = $row['description']; 
	          
              $catsql         = "SELECT * From `categories` WHERE `id`='$category_id'";
	          $catresult      = mysql_query($catsql);
	          if(mysql_num_rows($catresult)>0){

              $getname        = mysql_fetch_array($catresult);
              $categoryName   = $getname['name'];

              }
              $subsql         = "SELECT * From `subcategories` WHERE `id`='$subcategory_id'";
	          $subresult      = mysql_query($subsql);
	          if(mysql_num_rows($subresult)>0){
              $getname        = mysql_fetch_array($subresult);
              $subcategoryName   = $getname['name'];
              }
              
               $get_sql = "SELECT * From `wishlist` WHERE `productId`='$id' AND `userId`='$userId'";
               $get_result = mysql_query($get_sql);
               if(mysql_num_rows($get_result)>0){ $wishlist = '1'; }else{ $wishlist = '0'; }
              // 0 for => wishlist not added AND 1 for => product added wishlist

               $multi_image_data   = "SELECT * From `product_multi_image` WHERE `productId`='$id'";
               $multi_image_result = mysql_query($multi_image_data);
               if(mysql_num_rows($multi_image_result)>0){ 
               
               $multi_image_path = $this->product_image_path.'multiimage/'; 
               while($imageRow = mysql_fetch_array($multi_image_result)){
                

                $imageData[] = array( 'image' => $multi_image_path.$imageRow['image'] ); 

               }
               }else{

                $imageData = array(); 

               }

               $AttributeQuery    = "SELECT * From `product_fields_attributes` WHERE `productId`='$id'";
               $Attribute_result = mysql_query($AttributeQuery);
               if(mysql_num_rows($Attribute_result)>0){ 
               while($Attribute_row = mysql_fetch_array($Attribute_result)){
                

                $AttributeData[] = array(  $Attribute_row['attribute_key'] => $Attribute_row['attribute_value'] ); 

               }
               }else{

                $AttributeData = array(); 
               }

               $PR_EX_attribute    = "SELECT * From `product_attributes` WHERE `productId`='$id'";
               $PR_EX_result       = mysql_query($PR_EX_attribute);
               if(mysql_num_rows($PR_EX_result)>0){ 
               
               while($attribData   = mysql_fetch_array($PR_EX_result)){
                

                $Ex_Data[] = array( 
                	                  'attribute_id'    => $attribData['id'],  
                                      'product_code'    => $attribData['product_code'], 
                	                  'color'           => $attribData['product_color'],
                                      'size'            => $attribData['product_size'],
                                      'quantity'        => $attribData['product_quantity']
                                     
                                     ); 

               }

               }else{

               	$Ex_Data = array();
               	
               } 
               

             	$newArrival[] = array( 

              	               'productId'      => $id,
                               'name'           => $name,
                               'price'          => $price,
                               'image'          => $this->product_image_path.$image,
                               'categoryName'   => $categoryName,
                               'subcategoryName'=> $subcategoryName,
                               'size'           => $size,
                               'unit'           => $unit,
                               'productcode'    => $code,
                               'quantity'       => $quantity,
                               'wishlist'       => $wishlist,
                               'categoryId'     => $category_id,
                               'subcategoryId'  => $subcategory_id,
                               'type'           => $type,
                               'brand'          => $brand,
                               'description'    => $description,
                               'multiimage'     => $imageData,
                               'specification'  => $AttributeData,
                               'attribute'      => $Ex_Data
                               
                             );
                            $imageData     ='';
                            $AttributeData =''; 
                            $Ex_Data       ='';   
	        }

	        if($row['type']=='2'){
	          $id             = $row['id'];
	          $name           = $row['name'];
	          $price          = $row['price'];
	          $image          = $row['image'];
	          $category_id    = $row['category_id'];
	          $subcategory_id = $row['subcategory_id'];
	          $size           = $row['size'];
	          $unit           = $row['unit'];
	          $code           = $row['code'];
	          $quantity       = ($row['quantity'])?$row['quantity']:0;
	          $category_id    = $row['category_id'];
	          $subcategory_id = $row['subcategory_id'];
              $type           = $row['type']; 
              $brand          = $row['brand']; 
              $description    = $row['description']; 

	          
              $catsql         = "SELECT * From `categories` WHERE `id`='$category_id'";
	          $catresult      = mysql_query($catsql);
	          if(mysql_num_rows($catresult)>0){
              $getname        = mysql_fetch_array($catresult);
              $categoryName   = $getname['name'];
              }
              $subsql         = "SELECT * From `subcategories` WHERE `id`='$subcategory_id'";
	          $subresult      = mysql_query($subsql);
	          if(mysql_num_rows($subresult)>0){
              $getname        = mysql_fetch_array($subresult);
              $subcategoryName   = $getname['name'];
              }
              
               $get_sql = "SELECT * From `wishlist` WHERE `productId`='$id' AND `userId`='$userId'";
               $get_result = mysql_query($get_sql);
               if(mysql_num_rows($get_result)>0){ $wishlist = '1'; }else{ $wishlist = '0'; }
              // 0 for => wishlist not added AND 1 for => product added wishlist

               $multi_image_data   = "SELECT * From `product_multi_image` WHERE `productId`='$id'";
               $multi_image_result = mysql_query($multi_image_data);
               if(mysql_num_rows($multi_image_result)>0){ 
               
               $multi_image_path = $this->product_image_path.'multiimage/'; 
               while($imageRow = mysql_fetch_array($multi_image_result)){
                

                $imageData[] = array( 'image' => $multi_image_path.$imageRow['image'] ); 

               }
               }else{
                
                $imageData = array();

               }
               $AttributeQuery    = "SELECT * From `product_fields_attributes` WHERE `productId`='$id'";
               $Attribute_result = mysql_query($AttributeQuery);
               if(mysql_num_rows($Attribute_result)>0){ 
               while($Attribute_row = mysql_fetch_array($Attribute_result)){
                

                $AttributeData[] = array(  $Attribute_row['attribute_key'] => $Attribute_row['attribute_value'] ); 

               }
               }else{

                $AttributeData = array(); 
               }   
               
               $PR_EX_attribute    = "SELECT * From `product_attributes` WHERE `productId`='$id'";
               $PR_EX_result       = mysql_query($PR_EX_attribute);
               if(mysql_num_rows($PR_EX_result)>0){ 
               
               while($attribData   = mysql_fetch_array($PR_EX_result)){
                

                $Ex_Data[] = array( 
                	                  'attribute_id'    => $attribData['id'],  
                                      'product_code'    => $attribData['product_code'], 
                	                  'color'           => $attribData['product_color'],
                                      'size'            => $attribData['product_size'],
                                      'quantity'        => $attribData['product_quantity']
                                     
                                     ); 

               }

               }else{

               	$Ex_Data = array();
               	
               } 
               
              $feature[] = array( 'productId'   => $id,
                               'name'           => $name,
                               'price'          => $price,
                               'image'          => $this->product_image_path.$image,
                               'categoryName'   => $categoryName,
                               'subcategoryName'=> $subcategoryName,
                               'size'           => $size,
                               'unit'           => $unit,
                               'productcode'    => $code,
                               'quantity'       => $quantity,
                               'wishlist'       => $wishlist,
                               'categoryId'     => $category_id,
                               'subcategoryId'  => $subcategory_id,
                               'type'           => $type,
                               'brand'          => $brand,
                               'description'    => $description,  
                               'multiimage'     => $imageData, 
                               'specification'  => $AttributeData,
                               'attribute'      => $Ex_Data   
                             );

                        $imageData     = '';
                        $AttributeData = '';
                        $Ex_Data       = '';    
	        }
              
            if($row['type']=='3'){
	          $id             = $row['id'];
	          $name           = $row['name'];
	          $price          = $row['price'];
	          $image          = $row['image'];
	          $category_id    = $row['category_id'];
	          $subcategory_id = $row['subcategory_id'];
	          $size           = $row['size'];
	          $unit           = $row['unit'];
	          $code           = $row['code'];
	          $quantity       = ($row['quantity'])?$row['quantity']:0;
	          $category_id    = $row['category_id'];
	          $subcategory_id = $row['subcategory_id'];
              $type           = $row['type']; 
              $brand          = $row['brand']; 
              $description    = $row['description']; 
	          
              $catsql         = "SELECT * From `categories` WHERE `id`='$category_id'";
	          $catresult      = mysql_query($catsql);
	          if(mysql_num_rows($catresult)>0){
              $getname        = mysql_fetch_array($catresult);
              $categoryName   = $getname['name'];
              }
              $subsql         = "SELECT * From `subcategories` WHERE `id`='$subcategory_id'";
	          $subresult      = mysql_query($subsql);
	          if(mysql_num_rows($subresult)>0){
              $getname        = mysql_fetch_array($subresult);
              $subcategoryName   = $getname['name'];
              }
              
               $get_sql = "SELECT * From `wishlist` WHERE `productId`='$id' AND `userId`='$userId'";
               $get_result = mysql_query($get_sql);
               if(mysql_num_rows($get_result)>0){ $wishlist = '1'; }else{ $wishlist = '0'; }
              // 0 for => wishlist not added AND 1 for => product added wishlist

               $multi_image_data   = "SELECT * From `product_multi_image` WHERE `productId`='$id'";
               $multi_image_result = mysql_query($multi_image_data);
               if(mysql_num_rows($multi_image_result)>0){ 
               
               $multi_image_path = $this->product_image_path.'multiimage/'; 
               while($imageRow = mysql_fetch_array($multi_image_result)){
                

                $imageData[] = array( 'image' => $multi_image_path.$imageRow['image'] ); 

               }
               }else{

                $imageData = array();

               }

               $AttributeQuery    = "SELECT * From `product_fields_attributes` WHERE `productId`='$id'";
               $Attribute_result = mysql_query($AttributeQuery);
               if(mysql_num_rows($Attribute_result)>0){ 
               while($Attribute_row = mysql_fetch_array($Attribute_result)){
                

                $AttributeData[] = array(  $Attribute_row['attribute_key'] => $Attribute_row['attribute_value'] ); 

               }
               }else{

                $AttributeData = array(); 
               }
               
               $PR_EX_attribute    = "SELECT * From `product_attributes` WHERE `productId`='$id'";
               $PR_EX_result       = mysql_query($PR_EX_attribute);
               if(mysql_num_rows($PR_EX_result)>0){ 
               
               while($attribData   = mysql_fetch_array($PR_EX_result)){
                

                $Ex_Data[] = array( 
                	                  'attribute_id'    => $attribData['id'],  
                                      'product_code'    => $attribData['product_code'], 
                	                  'color'           => $attribData['product_color'],
                                      'size'            => $attribData['product_size'],
                                      'quantity'        => $attribData['product_quantity']
                                     
                                     ); 

               }

               }else{

               	$Ex_Data = array();
               	
               } 
               

              $best_seller[] = array( 

              	               'productId'      => $id,
                               'name'           => $name,
                               'price'          => $price,
                               'image'          => $this->product_image_path.$image,
                               'categoryName'   => $categoryName,
                               'subcategoryName'=> $subcategoryName,
                               'size'           => $size,
                               'unit'           => $unit,
                               'productcode'    => $code,
                               'quantity'       => $quantity,
                               'wishlist'       => $wishlist,
                               'categoryId'     => $category_id,
                               'subcategoryId'  => $subcategory_id,
                               'type'           => $type,
                               'brand'          => $brand, 
                               'description'    => $description,  
                               'multiimage'     => $imageData, 
                               'specification'  => $AttributeData,
                               'attribute'      => $Ex_Data   
                             );

                            $imageData     ='';
                            $AttributeData ='';   
                            $Ex_Data       ='';
	        }              
              
        	if($row['type']=='4'){
        	  $id             = $row['id'];
	          $name           = $row['name'];
	          $price          = $row['price'];
	          $image          = $row['image'];
	          $category_id    = $row['category_id'];
	          $subcategory_id = $row['subcategory_id'];
	          $size           = $row['size'];
	          $unit           = $row['unit'];
	          $code           = $row['code'];
	          $quantity       = ($row['quantity'])?$row['quantity']:0;
	          $category_id    = $row['category_id'];
	          $subcategory_id = $row['subcategory_id'];
              $type           = $row['type']; 
              $brand          = $row['brand']; 
              $description    = $row['description']; 
	          
              $catsql         = "SELECT * From `categories` WHERE `id`='$category_id'";
	          $catresult      = mysql_query($catsql);
	          if(mysql_num_rows($catresult)>0){
              $getname        = mysql_fetch_array($catresult);
              $categoryName   = $getname['name'];
              }
              $subsql         = "SELECT * From `subcategories` WHERE `id`='$subcategory_id'";
	          $subresult      = mysql_query($subsql);
	          if(mysql_num_rows($subresult)>0){
              $getname        = mysql_fetch_array($subresult);
              $subcategoryName   = $getname['name'];
              }
              
               $get_sql = "SELECT * From `wishlist` WHERE `productId`='$id' AND `userId`='$userId'";
               $get_result = mysql_query($get_sql);
               if(mysql_num_rows($get_result)>0){ $wishlist = '1'; }else{ $wishlist = '0'; }
              // 0 for => wishlist not added AND 1 for => product added wishlist

               $multi_image_data   = "SELECT * From `product_multi_image` WHERE `productId`='$id'";
               $multi_image_result = mysql_query($multi_image_data);
               if(mysql_num_rows($multi_image_result)>0){ 
               
               $multi_image_path = $this->product_image_path.'multiimage/'; 
               while($imageRow = mysql_fetch_array($multi_image_result)){
                

                $imageData[] = array( 'image' => $multi_image_path.$imageRow['image'] ); 

               }
               }else{

               	$imageData = array();

               }
               
               $AttributeQuery    = "SELECT * From `product_fields_attributes` WHERE `productId`='$id'";
               $Attribute_result = mysql_query($AttributeQuery);
               if(mysql_num_rows($Attribute_result)>0){ 
               while($Attribute_row = mysql_fetch_array($Attribute_result)){
                

                $AttributeData[] = array(  $Attribute_row['attribute_key'] => $Attribute_row['attribute_value'] ); 

               }
               }else{

                $AttributeData = array(); 
               }

               $PR_EX_attribute    = "SELECT * From `product_attributes` WHERE `productId`='$id'";
               $PR_EX_result       = mysql_query($PR_EX_attribute);
               if(mysql_num_rows($PR_EX_result)>0){ 
               
               while($attribData   = mysql_fetch_array($PR_EX_result)){
                

                $Ex_Data[] = array( 
                	                  'attribute_id'    => $attribData['id'],  
                                      'product_code'    => $attribData['product_code'], 
                	                  'color'           => $attribData['product_color'],
                                      'size'            => $attribData['product_size'],
                                      'quantity'        => $attribData['product_quantity']
                                     
                                     ); 

               }

               }else{

               	$Ex_Data = array();
               	
               } 
               

               $special_product[] = array( 'productId'      => $id,
                               'name'           => $name,
                               'price'          => $price,
                               'image'          => $this->product_image_path.$image,
                               'categoryName'   => $categoryName,
                               'subcategoryName'=> $subcategoryName,
                               'size'           => $size,
                               'unit'           => $unit,
                               'productcode'    => $code,
                               'quantity'       => $quantity,
                               'wishlist'       => $wishlist,
                               'categoryId'     => $category_id,
                               'subcategoryId'  => $subcategory_id,
                               'type'           => $type,
                               'brand'          => $brand,
                               'description'    => $description,  
                               'multiimage'     => $imageData,
                               'specification'  => $AttributeData,
                               'attribute'      => $Ex_Data  
                             );

	                        $imageData     = '';
	                        $AttributeData = '';                
	                        $Ex_Data       = '';
            } 
				
	  	} 
              
	          $data[] = array('new_arrival' => $newArrival , 'feature' => $feature ,'best_seller' => $best_seller, 'special_product' => $special_product); 
              $response['message']  = "Product List";
	          $response['msg_code'] = 1;     
	          $response['data']     = $data;       
 
	    }else{
             
             $response['message']  = "Product Data is Empty";
	         $response['msg_code'] = 0;     
        }

        return json_encode($response);	 

    }

/*************************************************************************************/
/***************************FOR SLIDER iMAGE LIST*************************************/
/*************************************************************************************/

    public function SliderImages($service_data){
        
             
            $sql    = "SELECT * From `sliderImages`";
            $result = mysql_query($sql);
            if(mysql_num_rows($result)>0){
            while($row = mysql_fetch_array($result)){ 

            $image        = $row['image'];	 
            $title        = $row['main_title'];	
            $sub_title    = $row['sub_title'];	
            $description  = $row['description'];	
            
            $data[] = array(

            	            'image'       => $this->slider_image_path.$image,
            	            'title'       => $title,
            	            'sub_title'   => $sub_title,
            	            'description' => $description
            	         );   
            }

            $response['message']  = "Slider Images";
		    $response['msg_code'] = 1;                           
		    $response['data']     = $data;                           

            }else{

            $response['message']  = "No Image";
		    $response['msg_code'] = 0;  

            }
        
        return json_encode($response);	  	         
    }  

 /*********************************************************************/
/*================SERVICE NO.23 -FOR filterproduct by Category=======================*/

    function GetProductByCategories($service_data){
      
      $userId        = $service_data['userId'];
      $categoryId    = $service_data['categoryId']; 
      $subcategoryId = $service_data['subcategoryId'];

        $sql       = "SELECT * From `products` WHERE `category_id`='$categoryId' AND `subcategory_id`='$subcategoryId'";
	    $result = mysql_query($sql);
	    if(mysql_num_rows($result)>0){
	        while ($row = mysql_fetch_array($result)){
	         
	          $id             = $row['id'];
	          $name           = $row['name'];
	          $price          = $row['price'];
	          $image          = $row['image'];
	          $category_id    = $row['category_id'];
	          $subcategory_id = $row['subcategory_id'];
	          $size           = $row['size'];
	          $unit           = $row['unit'];
	          $code           = $row['code'];
	          $quantity       = ($row['quantity'])?$row['quantity']:0;
	          $category_id    = $row['category_id'];
	          $subcategory_id = $row['subcategory_id'];
              $type           = $row['type'];
              $brand          = $row['brand'];  
              $description    = $row['description'];  
	          
              $catsql         = "SELECT * From `categories` WHERE `id`='$category_id'";
	          $catresult      = mysql_query($catsql);
	          if(mysql_num_rows($catresult)>0){
              $getname        = mysql_fetch_array($catresult);
              $categoryName   = $getname['name'];
              }
              $subsql         = "SELECT * From `subcategories` WHERE `id`='$subcategory_id'";
	          $subresult      = mysql_query($subsql);
	          if(mysql_num_rows($subresult)>0){
              $getname        = mysql_fetch_array($subresult);
              $subcategoryName   = $getname['name'];
              }
              
               $get_sql = "SELECT * From `wishlist` WHERE `productId`='$id' AND `userId`='$userId'";
               $get_result = mysql_query($get_sql);
               if(mysql_num_rows($get_result)>0){ $wishlist = '1'; }else{ $wishlist = '0'; }
              // 0 for => wishlist not added AND 1 for => product added wishlist

               $multi_image_data   = "SELECT * From `product_multi_image` WHERE `productId`='$id'";
               $multi_image_result = mysql_query($multi_image_data);
               if(mysql_num_rows($multi_image_result)>0){ 
               
               $multi_image_path = $this->product_image_path.'multiimage/'; 
               while($imageRow = mysql_fetch_array($multi_image_result)){
                

                $imageData[] = array( 'image' => $multi_image_path.$imageRow['image'] ); 

               }
               }else{

               	$imageData = array();
               	
               }

               $AttributeQuery    = "SELECT * From `product_fields_attributes` WHERE `productId`='$id'";
               $Attribute_result = mysql_query($AttributeQuery);
               if(mysql_num_rows($Attribute_result)>0){ 
               while($Attribute_row = mysql_fetch_array($Attribute_result)){
                

                $AttributeData[] = array(  $Attribute_row['attribute_key'] => $Attribute_row['attribute_value'] ); 

               }
               }else{

                $AttributeData = array(); 
               }
               
               $PR_EX_attribute    = "SELECT * From `product_attributes` WHERE `productId`='$id'";
               $PR_EX_result       = mysql_query($PR_EX_attribute);
               if(mysql_num_rows($PR_EX_result)>0){ 
               
               while($attribData   = mysql_fetch_array($PR_EX_result)){
                

                $Ex_Data[] = array( 
                	                  'attribute_id'    => $attribData['id'],  
                                      'product_code'    => $attribData['product_code'], 
                	                  'color'           => $attribData['product_color'],
                                      'size'            => $attribData['product_size'],
                                      'quantity'        => $attribData['product_quantity']
                                     
                                     ); 

               }

               }else{

               	$Ex_Data = array();
               	
               } 
               


              $data[] = array( 'productId'      => $id,
                               'name'           => $name,
                               'price'          => $price,
                               'image'          => $this->product_image_path.$image,
                               'categoryName'   => $categoryName,
                               'subcategoryName'=> $subcategoryName,
                               'size'           => $size,
                               'unit'           => $unit,
                               'productcode'    => $code,
                               'quantity'       => $quantity,
                               'wishlist'       => $wishlist,
                               'categoryId'     => $category_id,
                               'subcategoryId'  => $subcategory_id,
                               'type'           => $type,
                               'brand'          => $brand,
                               'description'    => $description,
                               'multiimage'     => $imageData ,
                               'specification'  => $AttributeData,
                               'attribute'      => $Ex_Data 
                             );

              $imageData ='';
              $AttributeData =''; 
              $Ex_Data ='';

              $response['message']  = "Product List";
	          $response['msg_code'] = 1;     
	          $response['data']     = $data;     
              
				
	          } 
 
	    }else{
             
             $response['message']  = "Product Data is Empty";
	         $response['msg_code'] = 0;     
        }
      
      return json_encode($response); 
	}     


/*********************************************************************/
/*================SERVICE NO.19 -FOR EDIT USER iMAGE=======================*/

    function FiltterProduct($service_data){
      
        $userId        = $service_data['userId'];
        $categoryId    = $service_data['categoryId']; 
        $priceRange    = $service_data['priceRange'];
        $productName   = $service_data['searchKeyword'];  
        
        $sql  = "SELECT * From `products` WHERE name LIKE '%".$productName."%'";

        

        if (isset($categoryId) && $categoryId!='') {
        
            $sql.= " AND category_id ='".$categoryId."'";	
        }

        // if(isset($productName) && $productName!='') {
           
        //     $sql.= " WHERE name LIKE '%".$productName."%'";		
        // }
        
        if (isset($priceRange) && $priceRange!='') {

	    	$length = count($priceRange);

	    	if ($length != 0) {
	    		
				$sql.=" AND(";

                for ($i=0; $i<$length; $i++) {
				  
			 	  $priceRangeArr = explode(' To ', $priceRange[$i]);

			 	  	$min = $priceRangeArr[0];
    				$max = $priceRangeArr[1];

    				if ($i == 0) {
    					$sql.=" (price BETWEEN '$min' AND '$max')";
    				}else{
    					$sql = $sql." OR "."(price BETWEEN '$min' AND '$max') ";
    				}
			 	}

				$sql.=")";
			}
		}

        $sql.=" GROUP BY products.id";   
	    $result = mysql_query($sql);
	    if(mysql_num_rows($result)>0){
	        while ($row = mysql_fetch_array($result)){
	         
	          $id             = $row['id'];
	          $name           = $row['name'];
	          $price          = $row['price'];
	          $image          = $row['image'];
	          $category_id    = $row['category_id'];
	          $subcategory_id = $row['subcategory_id'];
	          $size           = $row['size'];
	          $unit           = $row['unit'];
	          $code           = $row['code'];
	          $quantity       = ($row['quantity'])?$row['quantity']:0;
	          $category_id    = $row['category_id'];
	          $subcategory_id = $row['subcategory_id'];
              $type           = $row['type'];
              $brand          = $row['brand'];  
              $description    = $row['description'];  
	          
              $catsql         = "SELECT * From `categories` WHERE `id`='$category_id'";
	          $catresult      = mysql_query($catsql);
	          if(mysql_num_rows($catresult)>0){
              $getname        = mysql_fetch_array($catresult);
              $categoryName   = $getname['name'];
              }
              $subsql         = "SELECT * From `subcategories` WHERE `id`='$subcategory_id'";
	          $subresult      = mysql_query($subsql);
	          if(mysql_num_rows($subresult)>0){
              $getname        = mysql_fetch_array($subresult);
              $subcategoryName   = $getname['name'];
              }
              
               $get_sql = "SELECT * From `wishlist` WHERE `productId`='$id' AND `userId`='$userId'";
               $get_result = mysql_query($get_sql);
               if(mysql_num_rows($get_result)>0){ $wishlist = '1'; }else{ $wishlist = '0'; }
              // 0 for => wishlist not added AND 1 for => product added wishlist

               $multi_image_data   = "SELECT * From `product_multi_image` WHERE `productId`='$id'";
               $multi_image_result = mysql_query($multi_image_data);
               if(mysql_num_rows($multi_image_result)>0){ 
               
               $multi_image_path = $this->product_image_path.'multiimage/'; 
               while($imageRow = mysql_fetch_array($multi_image_result)){
                

                $imageData[] = array( 'image' => $multi_image_path.$imageRow['image'] ); 

               }
               }else{

               	$imageData = array();
               	
               }

               $AttributeQuery    = "SELECT * From `product_fields_attributes` WHERE `productId`='$id'";
               $Attribute_result = mysql_query($AttributeQuery);
               if(mysql_num_rows($Attribute_result)>0){ 
               while($Attribute_row = mysql_fetch_array($Attribute_result)){
                

                $AttributeData[] = array(  $Attribute_row['attribute_key'] => $Attribute_row['attribute_value'] ); 

               }
               }else{

                $AttributeData = array(); 
               }
               
               $PR_EX_attribute    = "SELECT * From `product_attributes` WHERE `productId`='$id'";
               $PR_EX_result       = mysql_query($PR_EX_attribute);
               if(mysql_num_rows($PR_EX_result)>0){ 
               
               while($attribData   = mysql_fetch_array($PR_EX_result)){
                

                $Ex_Data[] = array( 
                	                  'attribute_id'    => $attribData['id'],  
                                      'product_code'    => $attribData['product_code'], 
                	                  'color'           => $attribData['product_color'],
                                      'size'            => $attribData['product_size'],
                                      'quantity'        => $attribData['product_quantity']
                                     
                                     ); 

               }

               }else{

               	$Ex_Data = array();
               	
               } 
               

              $data[] = array( 'productId'      => $id,
                               'name'           => $name,
                               'price'          => $price,
                               'image'          => $this->product_image_path.$image,
                               'categoryName'   => $categoryName,
                               'subcategoryName'=> $subcategoryName,
                               'size'           => $size,
                               'unit'           => $unit,
                               'productcode'    => $code,
                               'quantity'       => $quantity,
                               'wishlist'       => $wishlist,
                               'categoryId'     => $category_id,
                               'subcategoryId'  => $subcategory_id,
                               'type'           => $type,
                               'brand'          => $brand,
                               'description'    => $description,
                               'multiimage'     => $imageData ,
                               'specification'  => $AttributeData,
                               'attribute'      => $Ex_Data  
                             );

              $imageData='';
              $AttributeData ='';
              $Ex_Data = '';
              $response['message']  = "Product List";
	          $response['msg_code'] = 1;     
	          $response['data']     = $data;     
              
				
	          } 
 
	    }else{
             
             $response['message']  = "Product Data is Empty";
	         $response['msg_code'] = 0;     
        }
      
      return json_encode($response); 
	}

/*********************************************************************/
/*================SERVICE NO.25 -FOR shiping Address=======================*/

    function updateShippingAddress($service_data)
		{
			
            $addedDate         = $this->default_datetime_zone();
			$id                = $service_data['userId'];
		    $shipping_address  = $service_data['shipping_address']; 
		    $title             = $service_data['title'];
            

			$updt_user = "UPDATE `customers` SET `shipping_address` = '$shipping_address',`title` = '$title', `update_date` = '$addedDate' WHERE `id` = '$id' AND `active_status` ='1'";    
			$query=mysql_query($updt_user) or die(mysql_error());
			if(mysql_affected_rows()>0)
				{
					$response['message']="Shipping Address successfully Update";
					$response['msg_code']=1;
				}else{
                    $response['message']="Shipping Address is Not Update.";
                    $response['msg_code']=0;
                }
               
             
            return json_encode($response);
		}	

/*********************************************************************/
/*================SERVICE NO.26 -FOR shiping Address=======================*/

    function userinfoById($service_data){ 

        $userId     = $service_data['userId'];
        $image_path = $this->image_path; 
        $sql1       = "SELECT * From customers WHERE id = '$userId' and `active_status`='1'";
        $result2    = mysql_query($sql1);
		if(mysql_num_rows($result2)>0){
        $row =  mysql_fetch_array($result2);
        

                        $image  = $row['image'];

                        if(filter_var($image, FILTER_VALIDATE_URL))
						{
						    
						    $image_url = $row['image'];
						}
						elseif( base64_encode(base64_decode($image, true)) === $image){
						 
						    $image_url = $image_path.$row['image'];
                        }

            $data[] = array( 
            	            
            	            'userId'           =>$row['id'],
            	            'name'             =>$row['name'],
            	            'image'            =>$image_url,
            	            'contact'          =>$row['phone'],
            	            'email'            =>$row['email'],
            	            'creat_date'       =>$row['creat_date'],
            	            'edit_date'        =>$row['update_date'],
            	            'address'          =>$row['address'],
            	            'shipping_address' =>$row['shipping_address'],
            	            'title'            =>$row['title']

            	            );   

                $response['message']   = "User Data";
				$response['msg_code']  = 1;
				$response['data']      = $data;  

        }else{
                
                $response['message']   = "Please login First";
				$response['msg_code']  = 0;

        }
                

                return json_encode($response);
    }


/**************************--End--***********************************/	
}
/**************************--End--***********************************/
     //$a = new api();
     //print_r($a->userLogin());


?>