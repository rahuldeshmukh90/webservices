<?php
           error_reporting(0);
           $hostname = "localhost";
	       $username = "impetqry_softwar";
	       $password = "software@123";
	       $db       = "impetqry_software";
	
	       //connection to the database
	       $dbhandle = mysql_connect($hostname,$username,$password) or die("unable to connect to mysql");
	       //select a database to work with
	       $selected = mysql_select_db($db,$dbhandle) or die("Could not select database.");

?>