<?php 


include_once('api.php');


$data = json_decode(file_get_contents('php://input'), true);

//print_r( $data["data"]); 

$function_name=$data["function_name"];
 
$params=$data["data"];

if(!empty($params) && !empty($function_name))
{
	$api = new api();
	$name = $api->$function_name($params);
	print_r($name);
}
else if(!empty($function_name))
{
	$api = new api();
	$name = $api->$function_name($function_name);
	print_r($name);
}else{

echo "error eccurred.";
}

?>